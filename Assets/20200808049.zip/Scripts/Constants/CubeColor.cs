using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CubeColor {
    
    Blue = 0,
    Yellow = 1,
    
}
